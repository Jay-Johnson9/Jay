#!/bin/bash

pipenv run main \
    --disable-secret-scanning \
    --disable-code-scanning
