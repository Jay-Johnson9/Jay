#!/bin/bash

pipenv run main \
    --disable-dependabot \
    --disable-dependency-licensing
