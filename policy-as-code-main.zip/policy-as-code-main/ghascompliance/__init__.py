from ghascompliance.__version__ import *
