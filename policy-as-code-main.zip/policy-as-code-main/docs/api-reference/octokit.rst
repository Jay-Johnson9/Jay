.. _octokit:

Octokit API
==============================


GitHub
------------
.. module:: ghascompliance.octokit.octokit

.. autoclass:: GitHub
   :members:


Octokit
------------
.. module:: ghascompliance.octokit.octokit

.. autoclass:: Octokit
   :members:


OctoRequests
------------
.. module:: ghascompliance.octokit.octokit

.. autoclass:: OctoRequests
   :members:

