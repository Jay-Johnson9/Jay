Samples
------------

Examples and samples for all the common use-cases.

.. toctree::
   :maxdepth: 1

   default-policy
   typosquatting
